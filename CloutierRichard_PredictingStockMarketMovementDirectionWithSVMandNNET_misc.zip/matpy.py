import pickle

with open('pickles/AMDdaily.pkl', 'rb') as f:
    t = pickle.load(f)

print(p)
